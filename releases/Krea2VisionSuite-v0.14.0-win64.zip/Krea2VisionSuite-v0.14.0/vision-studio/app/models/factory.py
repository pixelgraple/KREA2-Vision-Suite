from dataclasses import dataclass
from pathlib import Path

from ..config import ROOT, Settings
from ..services.model_catalog import ModelSpec, resolve_model
from .llama_cpp_provider import LlamaCppProvider
from .ollama_provider import OllamaProvider
from .openai_compatible_provider import OpenAICompatibleProvider
from .remote_access import RemoteAccess
from .remote_gateway_provider import RemoteGatewayProvider
from .vast_serverless_provider import VastServerlessProvider


@dataclass(frozen=True)
class LlamaCppRuntimeProfile:
    gpu_layers: int | str
    adaptive_gpu_fit: bool
    fit_target_mb: int | None
    minimum_gpu_allocation_mb: int


def llama_cpp_runtime_profile(settings: Settings, spec: ModelSpec) -> LlamaCppRuntimeProfile:
    """Return the single runtime/admission contract for a local GGUF model."""

    gemma4_12b = spec.provider_model.startswith("gemma4-12b-")
    if gemma4_12b:
        return LlamaCppRuntimeProfile(
            # Leaving this argument unset lets llama.cpp's supported --fit
            # path choose the safe number of CUDA-resident layers at launch.
            gpu_layers="auto",
            adaptive_gpu_fit=True,
            fit_target_mb=max(1024, int(settings.llama_cpp_vram_headroom_mb)),
            minimum_gpu_allocation_mb=4096,
        )
    return LlamaCppRuntimeProfile(
        gpu_layers="all",
        adaptive_gpu_fit=False,
        fit_target_mb=None,
        minimum_gpu_allocation_mb=max(0, int(spec.estimated_vram_mb)),
    )


def provider_for(settings: Settings, spec: ModelSpec | None = None, telemetry_callback=None, remote_access: RemoteAccess | None = None):
    """Construct a provider from a server-resolved model specification."""

    backend = settings.backend.lower()
    if spec is None and backend in {"openai", "openai_compatible"}:
        return OpenAICompatibleProvider(
            settings.api_base,
            settings.api_key,
            settings.model,
            settings.max_output_tokens,
        )
    selected = spec or resolve_model(settings.model, settings)
    context = min(settings.context_length, selected.context_cap)
    max_tokens = min(settings.max_output_tokens, selected.max_output_cap, context - 1)
    if selected.backend == "ollama":
        return OllamaProvider(
            settings.api_base,
            selected.provider_model,
            context,
            max_tokens,
            settings.keep_alive,
        )
    if selected.backend == "llama_cpp":
        if selected.server_exe is None or selected.model_path is None or selected.mmproj_path is None:
            raise RuntimeError("The selected llama.cpp model is not available locally.")
        telemetry_path = Path(settings.llama_cpp_telemetry_path).expanduser()
        if not telemetry_path.is_absolute():
            telemetry_path = ROOT / telemetry_path
        gemma4_vision = selected.provider_model.startswith("gemma4-")
        runtime_profile = llama_cpp_runtime_profile(settings, selected)
        return LlamaCppProvider(
            server_exe=selected.server_exe,
            model_path=selected.model_path,
            mmproj_path=selected.mmproj_path,
            alias=selected.provider_model,
            host="127.0.0.1",
            port=settings.llama_cpp_port,
            context=context,
            max_tokens=max_tokens,
            startup_timeout=settings.llama_cpp_startup_timeout_seconds,
            telemetry_callback=telemetry_callback,
            runtime_log_path=telemetry_path.parent / "llama_cpp_server.log",
            # Gemma 4 CUDA projector inference can hard-crash on RTX 5090.
            # Keep only that projector on CPU and bound dynamic image tokens;
            # the language model layers remain fully GPU-offloaded.
            mmproj_offload=not gemma4_vision,
            image_min_tokens=256 if gemma4_vision else None,
            image_max_tokens=256 if gemma4_vision else 4096,
            image_max_side=768 if gemma4_vision else None,
            # Gemma 4 12B is allowed to adapt the CUDA/CPU layer split to the
            # measured post-handoff capacity. Other model families retain
            # their exact full-GPU profile.
            gpu_layers=runtime_profile.gpu_layers,
            fit_target_mb=runtime_profile.fit_target_mb,
        )
    if selected.backend == "vast_serverless":
        if settings.remote_gateway_url:
            if remote_access is None:
                raise RuntimeError("A remote KREA2 license is required for Online API Vision.")
            return RemoteGatewayProvider(
                base_url=settings.remote_gateway_url,
                model=selected.provider_model,
                max_tokens=max_tokens,
                timeout=settings.vast_serverless_request_timeout_seconds,
                access=remote_access,
            )
        python_exe = Path(settings.vast_serverless_python_exe).expanduser()
        if not python_exe.is_absolute():
            python_exe = ROOT / python_exe
        return VastServerlessProvider(
            endpoint=settings.vast_serverless_endpoint,
            api_key=settings.vast_serverless_api_key,
            model=selected.provider_model,
            max_tokens=max_tokens,
            timeout=settings.vast_serverless_request_timeout_seconds,
            python_exe=python_exe,
            bridge_script=ROOT / "app" / "models" / "vast_serverless_client.py",
        )
    if selected.backend in {"openai", "openai_compatible"}:
        return OpenAICompatibleProvider(
            settings.api_base,
            settings.api_key,
            selected.provider_model,
            max_tokens,
        )
    raise RuntimeError(f"Unsupported Vision backend '{selected.backend}'.")
