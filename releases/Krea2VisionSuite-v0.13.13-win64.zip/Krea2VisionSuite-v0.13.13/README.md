# KREA2 Vision Suite

KREA2 Vision Suite is a free, local-first Windows toolkit for turning Discord images into detailed image-generation prompts. The supported product has two components:

- `vision-studio/` — the backend-only FastAPI Vision and model service on `127.0.0.1:7870`;
- `betterdiscord-plugin/` — a focused BetterDiscord image magnifier, session-only prompt rail, three-prompt voting, opt-in Krea2 preference guidance, and first-run model/VRAM selector.

`prompt-assistant/` is retained only as archived development source. It is not installed, started, or exposed by the supported BetterDiscord product.

AI inference remains private. Full-resolution source images and generated prompt text are not cached locally; the plugin keeps only a bounded 640 px Prompt History thumbnail cache so completed results retain their image preview. Successful prompt text is contributed to the Krea2 provenance database under the disclosed contribution contract. Model weights, tokens, logs, and runtime telemetry are intentionally excluded from source control.

## Download

Recommended installation: open **Windows PowerShell**, paste the following command, and press Enter. It downloads the current stable ZIP without browser Mark-of-the-Web propagation, verifies its exact manifest size and SHA-256, and starts the guided installer:

```powershell
$p="$env:TEMP\Install-KREA2VisionSuite.ps1"; Invoke-WebRequest "https://raw.githubusercontent.com/pixelgraple/KREA2-Vision-Suite/main/Install-KREA2VisionSuite.ps1" -OutFile $p; powershell -NoProfile -ExecutionPolicy Bypass -File $p
```

Manual package: **[Krea2VisionSuite-v0.13.13-win64.zip](https://raw.githubusercontent.com/pixelgraple/KREA2-Vision-Suite/main/releases/Krea2VisionSuite-v0.13.13-win64.zip)**. Before extracting a browser-downloaded ZIP, right-click it, select **Properties**, enable **Unblock**, and select **Apply**. This prevents Windows SmartScreen from inheriting Internet Zone metadata onto the bundled scripts. Then extract it and run **`START HERE - INSTALL.bat`**.

Do not download only the BetterDiscord `.plugin.js` file. The complete ZIP contains the local Vision backend, installer, repair tools, and all required source code. Model weights are downloaded and hash-verified by the installer because their third-party licenses do not permit treating them as part of this repository.

For a concise public installation guide, see [Install KREA2 Vision Suite](docs/QUICK_START_FRIENDS.md). A ready-to-paste Discord announcement is available in [Discord installation post](docs/DISCORD_INSTALL_POST.md).

## Highlights

- Exact Qwen3-VL Heretic choices: 2B F16, 4B Q8_0, and 8B Q8_0 with matching Q8_0 multimodal projectors.
- First-run BetterDiscord setup for the pinned 2B–32B local model catalog, sorted by parameter size with exact body/projector download buttons, live free VRAM, conservative estimate, measured peak, a separate 4,096 MiB reserve, and final admission requirement.
- Shared FIFO scheduling with Forge/KREA-compatible tickets; Discord yields after one image job and may retain a model for up to 15 seconds only while no competing ticket exists.
- The installer verifies BetterDiscord inside the current Discord Stable app version, not merely its old runtime files. Running Install, Update or Repair after a Discord client update reinjects the official BetterDiscord build when needed.
- Session-only prompt history, live one-second queued/running details, cooperative cancel/clear controls, three grounded prompt variations, and session-only like/dislike feedback.
- A dedicated joint-and-contact pose pass followed by an independent pose verification audit and a final reconstruction audit. Standing, kneeling, crouching, torso bend, knee clearance, hip height, foot support, hand contacts, head/neck direction and camera proof become explicit reconstruction constraints instead of generic pose wording.
- Crop boundaries are hard evidence boundaries. When the pelvis, knees, feet, support surface, clothing or anatomy needed to prove a claim is outside the frame, Vision records it as undetermined and prevents the three final prompts from inventing an off-frame posture, contact, garment, body part or prop.
- Qwen/Gemma Heretic selections write and audit their own three final prompts directly. The optional `babegen-prompter:9b-q5` dependency is retained only for the separately selectable legacy compatibility path, not as a second rewrite pass over modern Vision output.
- Stable Subject A/B/C tracking for multi-person scenes binds each person's presentation, directly visible anatomy, clothing, limbs, pose, spatial position, actions and contact regions to the correct participant. Identity is not guessed from pixels or anatomy; the Interrogate tab accepts an optional session-only uploader note when exact identity labels or pronouns are known.
- Optional default-off Krea2 guidance using eight random approved examples plus up to four liked and three disliked local examples; downvoted sample combinations are not reused.
- Separate default-off failure diagnostics with an explicit disclosure, bounded upload/rate limits, owner-only Seedframe review, and a nonblocking transport that can never cause a Vision job to fail.
- Supported Discord image context-menu actions, explicit contribution privacy receipts, and a Windows installer/updater/repair center.
- Secure suite-wide update checks shortly after plugin startup and every six hours. The default presents a clear one-click install prompt; users may choose verified automatic updates in plugin settings. The loopback broker accepts only the pinned GitHub release location, exact manifest byte length, and SHA-256, then waits for active Vision work to finish before updating the matched plugin and backend together.
- Local GPU / Online API selection in BetterDiscord; Online mode disables local model selection and routes the fixed Gemma 4 26B-A4B model through the private loopback broker only when that operator has configured a Vast endpoint and private credential. An unavailable Online mode cannot be saved.
- Strict loopback routing, a random local Vision token used only for session exchange, and request-bound one-use sessions for image POSTs.

## Heretic models and guardrails

The included Heretic variants are designed not to refuse an image-description or prompt request. This software still applies its own local input validation, grounded-output and quality checks, GPU admission rules, and security limits. Those project guardrails can stop or reject a request even when the Heretic model itself did not refuse.

See [Model choices and VRAM](docs/MODELS.md) for exact files, links, checksums, and measured allocations.

## Install

Use the verified PowerShell bootstrap under **Download**, or unblock and extract the manual ZIP before double-clicking **`START HERE - INSTALL.bat`**. The guided installer does the rest:

- detects or installs Discord Stable, BetterDiscord, Python 3.12, and Ollama with user-scoped Windows packages;
- installs an isolated Python environment for the backend-only Vision service;
- creates and wires private local tokens automatically;
- downloads the pinned llama.cpp CUDA runtime, the recommended Qwen3-VL 8B Heretic body and matching projector, and the pinned Ollama compatibility composer used by the optional legacy model path;
- verifies every downloaded model/runtime artifact before accepting it;
- installs the BetterDiscord plugin, creates **Start** and **Repair** desktop shortcuts, registers the required backend services for hidden login startup, starts them, and health-checks ports 7870 and 11434;
- opens Discord's first-run model/VRAM screen, where the only normal user choice is whether to enable image actions for the current server.

Existing valid programs, models, and settings are reused. Legacy saved images, sidecars, and history databases are not reused in strict privacy mode. Interrupted model downloads resume. See [Windows installation](docs/INSTALL_WINDOWS.md) for screenshots-free troubleshooting, optional models, and advanced/manual commands.

For a short handoff you can send directly to friends, use [Friend quick start](docs/QUICK_START_FRIENDS.md).

BetterDiscord setup offers an optional **Automatically contribute my three generated prompts to Krea2** setting. When enabled after the user accepts the current [Seedframe Terms](https://seedframe.xyz/policies/terms), every successful Vision job submits its three generated prompt texts through the authenticated local Vision broker. When disabled, Vision still works and no generated prompt is contributed. No Seedframe endpoint or token is configured in BetterDiscord, and no source image, Discord identity or URL, filename, image hash, or local path is uploaded; submissions remain review-required until separately curated.

## Development checks

```powershell
cd vision-studio
python -m unittest discover -s tests -v

cd ..\betterdiscord-plugin
node .\build-inline-plugin.js
node .\Krea2DiscordCollector.test.js
node --test .\Krea2DiscordCollector.dataset-guidance.test.js
node --test .\Krea2DiscordCollector.feedback.test.js
node --test .\parser\png-prompt-metadata.test.js
```

## Build the Windows release ZIP

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\Build-Release.ps1
```

The build writes the versioned ZIP and SHA-256 checksum under `release\`. It includes only the supported Discord Vision product and excludes private settings, models, caches, logs, runtime data, and the archived Prompt Assistant source.
It also writes `release\latest.json`, the stable update manifest consumed by installed plugins. Publish the source tree, ZIP, checksum, and manifest in the same GitHub commit for every release.

## Security and privacy

Read [SECURITY.md](SECURITY.md) before exposing any port. The supported deployment is loopback-only. Do not publish `.env`, handoff tokens, model weights, the Krea2 provenance database, or logs. Strict privacy mode creates no saved Discord originals, prompt sidecars, or history databases.

An optional pinned Vast Serverless worker is included under `vast-serverless-gemma26`. It runs Gemma 4 26B-A4B Heretic Q3_K_L on one 24 GB GPU (RTX 3090 or RTX 4090 preferred) while preserving the loopback-only BetterDiscord boundary. The Vast endpoint and API key stay in the local broker environment and are never exposed to BetterDiscord. Image POSTs use request-bound one-use loopback sessions. The exact public model/projector are hash-verified before startup, and the remote choice is disabled by default. Provision at least 65 GB of worker disk; startup enforces download headroom and a separate 6 GiB free-space reserve. The production endpoint may scale to three workers under load, while `min_load=0` and an 8-second inactivity timeout avoid keeping paid GPU compute active solely for idle capacity.

Do not distribute the operator's Vast API key to friends. Friends can use local mode immediately. Shared public Online API access requires a separate HTTPS gateway with per-user credentials, quotas, revocation, rate limits, and abuse controls; that public gateway is not part of this local-first release.

## Third-party software and models

BetterDiscord is an unofficial Discord client modification; use it at your own risk and review Discord's current terms. Model weights and llama.cpp are separate third-party works governed by their own licenses and model cards. They are not redistributed in this repository.

KREA2 Vision Suite is released under the [MIT License](LICENSE).
